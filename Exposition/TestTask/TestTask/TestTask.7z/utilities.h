#pragma once

#include "accessory.h"

int hexToInt(const char * source, uint * position);

void runThroughWhitespaces(const char * source, uint * position);