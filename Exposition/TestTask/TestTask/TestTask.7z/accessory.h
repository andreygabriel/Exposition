#pragma once

#define ERROR_RETURN_VALUE -1
#define SUCCESS_RETURN_VALUE 0

typedef unsigned uint;
typedef unsigned char uchar;
