#pragma once

#include "accessory.h"
#include "utilities.h"

void parseLog( const char *logPath );
